import React, { useState } from 'react'
import Home from './pages/Home/Home'

export default function App() {
  return (
    <div className="min-h-screen bg-[#0b0b0f] text-white">
      <Home />
    </div>
  )
}