import React from 'react';
import Comp from './Home/HomePage.jsx';
export default function Home() { return <div className='p-6'><Comp /></div> }
