TrollCity Frontend (Vite + React + Tailwind)

How to run:
1. unzip this folder
2. npm install
3. create a .env file with VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY
4. npm run dev

Theme: Neon red (accent) + grey dark background